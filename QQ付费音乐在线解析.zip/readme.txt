直接上传主机即可使用
解析是QQ音乐歌曲链接或者QQ歌曲id，不是音乐名字！
如《奔赴星空》的
音乐链接为http://y.qq.com/n/yqq/song/001bX2td0m37s5.html
id为001bX2td0m37s5
可以解析全部vip歌曲，获取下载链接
BY：云猫