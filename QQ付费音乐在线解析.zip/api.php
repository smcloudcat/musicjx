<?php
/*
 *请求接口文件
 */
$type=$_POST["type"];
$url=$_POST["url"];
$id=$_POST["id"];
if($type==null)exit('{"code":0,"msg":"请输入方式"}');
if($type==1){$urls="http://api.lq520.club/api/qqvipmusic.php?url=https://y.qq.com/n/yqq/song/".$id.".html";
}elseif($type==2){$urls="http://api.lq520.club/api/qqvipmusic.php?url=".$url."";
}else{$urls="http://api.lq520.club/api/qqvipmusic.php?url=".$url."";}
$curl=curl_init();//初始化curl
$ua='Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
curl_setopt($curl, CURLOPT_URL, $urls);//访问的url
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//以文件流显示
curl_setopt($curl, CURLOPT_USERAGENT, $ua);//百度蜘蛛
curl_setopt($curl, CURLOPT_TIMEOUT, 20);//防止死循环
$result=curl_exec($curl);//返回结果
curl_close($curl);//关闭curl
echo $result;
?>